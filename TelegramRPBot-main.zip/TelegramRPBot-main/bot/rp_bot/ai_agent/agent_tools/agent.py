import io
import asyncio
from datetime import datetime
from typing import (
    Optional,
    Union,
    AsyncGenerator,
    List,
    Protocol,
    Type,
    Literal,
)
from logging import Logger
from pydantic import BaseModel, Field, ConfigDict, create_model
from omnimodkit.models_toolkit import ModelsToolkit, AvailableModelType
from omnimodkit.base_toolkit_model import OpenAIMessage
from motor.motor_asyncio import AsyncIOMotorDatabase
from .agent_toolkit import AIAgentToolkit
from ...prompt_manager import PromptManager
from ...memory_manager import MemoryManager
from ...agent_runtime import AgentInput, MemoryState
from ...openai_agents_runtime import OpenAIAgentsRuntime
from ...memory_utils import get_participant_key
from ....models.handlers_input import Person, Context, Message, TranscribedMessage


class AIAgentResponseOutputTypeModel(Protocol):
    """Protocol for dynamically created models with output_type field."""

    output_type: Union[type, object]


class TextStreamingResponse(BaseModel):
    """
    The most common output type - use it by default.
    By selecting this output type, the text generation will be used.
    """

    text_response: bool = Field(
        default=False,
        description="Indicates if the response is a text response.",
    )


class AudioResponse(BaseModel):
    """
    By selecting this output type, the audio generation will be used.
    Use this output type only when excplitily requested since it is expensive.
    """

    audio_text_to_generate: str = Field(
        default="",
        description="Audio text to generate in the language of the user.",
    )
    voice: Literal["alloy", "echo", "fable", "onyx", "nova", "shimmer"] = Field(
        default="alloy",
        description=(
            "Use alloy by default. However if user requests something specific, choose according to the following personas:\n"
            "alloy - warm, clear, and versatile; a balanced voice that adapts easily to formal or casual settings.\n"
            "echo - energetic and bright, with an expressive, youthful enthusiasm that makes conversations feel lively.\n"
            "fable - calm, narrative, and a bit whimsical; sounds like a storyteller guiding listeners through ideas.\n"
            "onyx - deep, confident, and steady; conveys authority and composure without being harsh.\n"
            "nova - friendly, approachable, and modern; upbeat and easygoing, like chatting with a helpful companion.\n"
            "shimmer - gentle, melodic, and slightly playful; soothing with a touch of sparkle, making interactions feel engaging and pleasant."
        ),
    )


class TextWithImageStreamingResponse(BaseModel):
    """
    By selecting this output type, the text generation will be used along with image generation.
    Note that the image generation is expensive and should be used only when explicitly requested
    or when it corresponds to the agent's personality.
    """

    text_generation_needed: bool = Field(
        default=False,
        description="Indicates if text generation is needed.",
    )
    image_description_to_generate: str = Field(
        default="",
        description="Description of the generated image in the language of the user.",
    )


class ChatFact(BaseModel):
    user_fact: str = Field(description="a fact about the user")
    user_handle: str = Field(
        description="the user's handle (e.g., '@username'), NOT their display name or first name"
    )


class ResponseFactsGeneration(BaseModel):
    facts_generation_needed: bool = Field(
        default=False,
        description=(
            "Indicates if the response requires facts generation. "
            "Note that the fact extraction is called on each user message, "
            "so you need to be very sure that the facts generation is needed. "
            "Only when a very important fact that is clearly truthful and cannot be easily inferred from the context, "
            "should you set this to True and generate the facts."
        ),
    )
    user_facts: Optional[List[ChatFact]] = Field(
        default=None,
        description=(
            "List of facts about the user. Be resourceful and generate facts only when necessary. "
            "If facts are not needed, set this field to null."
        ),
    )


class AIAgentStreamingResponse(BaseModel):
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
    )

    is_final_response: bool = Field(
        default=True,
        description="Indicates if the response is the final response.",
    )
    total_text: Optional[str] = Field(
        default=None,
        description="Text response from the model.",
    )
    text_new_chunk: Optional[str] = Field(
        default=None,
        description="New chunk of text response from the model.",
    )
    image_url: Optional[str] = Field(
        default=None,
        description="Generated image URL response from the model.",
    )
    image_description: Optional[str] = Field(
        default=None,
        description="Description of the generated image.",
    )
    audio_bytes: Optional[io.BytesIO] = Field(
        default=None,
        description="In-memory audio bytes response from the model.",
    )
    audio_description: Optional[str] = Field(
        default=None,
        description="Description of the generated audio.",
    )
    total_price: Optional[float] = Field(
        default=None,
        description="Total price of the model response based on input and output.",
    )
    transcribed_user_message: TranscribedMessage = Field(default=None)
    generated_facts: List[ChatFact] = Field(
        default_factory=list, description="Generated facts about the users in the chat."
    )


class AIAgent:
    def __init__(
        self,
        person: Person,
        context: Context,
        message: Message,
        db: AsyncIOMotorDatabase,
        models_toolkit: ModelsToolkit,
        prompt_manager: PromptManager,
        memory_manager: MemoryManager,
        autofact_enabled: bool,
        logger: Logger,
    ):
        self.person = person
        self.context = context
        self.message = message
        self.db = db
        self.models_toolkit = models_toolkit
        self.prompt_manager = prompt_manager
        self.memory_manager = memory_manager
        self.toolkit = AIAgentToolkit(
            person, context, message, db, models_toolkit, prompt_manager
        )
        self.models_toolkit = models_toolkit
        self.autofact_enabled = autofact_enabled
        self.logger = logger

    async def _get_transcribed_message(self) -> TranscribedMessage:
        # Note that here the responsibility to pass NULL images and Audio is on the
        # outer level bot processing (TG bot or other bot)
        image_description = (
            str(
                await self.models_toolkit.vision_model.arun_default(
                    in_memory_image_stream=self.message.in_file_image
                )
            )
            if self.message.in_file_image
            else None
        )
        voice_description = (
            str(
                await self.models_toolkit.audio_recognition_model.arun_default(
                    in_memory_audio_stream=self.message.in_file_audio
                )
            )
            if self.message.in_file_audio
            else None
        )
        return TranscribedMessage(
            message_text=self.message.message_text,
            timestamp=self.message.timestamp,
            image_description=image_description,
            voice_description=voice_description,
        )

    def _compose_user_input(
        self,
        user_input: Optional[str] = None,
        image_description: Optional[str] = None,
        audio_description: Optional[str] = None,
    ) -> str:
        prompts = []
        if user_input:
            prompts.append(user_input)
        if image_description:
            prompts.append(image_description)
        if audio_description:
            prompts.append(audio_description)
        return "\n".join(prompts)

    def _can_use_model(self, model_type: AvailableModelType) -> bool:
        """
        Check if a specific model type is allowed.
        """
        return self.models_toolkit.can_use_model(model_type)

    def _get_allowed_output_types(self) -> List[type]:
        """
        Get the list of allowed output type classes based on allowed_models.
        """
        allowed_types = []

        if self._can_use_model("text"):
            allowed_types.append(TextStreamingResponse)

        if self._can_use_model("audio_generation"):
            allowed_types.append(AudioResponse)

        if self._can_use_model("text") and self._can_use_model("image_generation"):
            allowed_types.append(TextWithImageStreamingResponse)

        return allowed_types

    def _create_dynamic_output_type_model(self) -> Type[AIAgentResponseOutputTypeModel]:
        """
        Create a dynamic output type model based on allowed models.
        """
        allowed_types = self._get_allowed_output_types()

        union_types = allowed_types or [TextStreamingResponse]

        if len(union_types) == 1:
            union_type = union_types[0]
        else:
            union_type = Union[tuple(union_types)]

        DynamicAIAgentStreamingResponseType = create_model(
            "DynamicAIAgentStreamingResponseType",
            output_type=(
                union_type,
                Field(description="Type of output expected from the model."),
            ),
        )

        return DynamicAIAgentStreamingResponseType

    async def astream(self) -> AsyncGenerator[AIAgentStreamingResponse, None]:
        """
        Asynchronously run the OmniModel with the provided inputs and return the output.
        """
        transcribed_user_message = await self._get_transcribed_message()
        prepared_memory_context = await self.memory_manager.prepare_context(
            initiator=self.person,
            context=self.context,
            user_transcribed_message=transcribed_user_message,
        )
        for shadow_result in prepared_memory_context.shadow_tool_results:
            self.logger.info(
                "Memory shadow tool %s returned %s result(s)",
                shadow_result.tool_name,
                shadow_result.result_count,
            )
        user_input = prepared_memory_context.user_input
        system_prompt = await self.prompt_manager.get_reply_system_prompt(
            context=self.context
        )
        if self.memory_manager.should_use_live_agent():
            try:
                async for response in self._astream_openai_agent(
                    transcribed_user_message=transcribed_user_message,
                    prepared_user_input=user_input,
                    system_prompt=system_prompt,
                    scope_key=prepared_memory_context.scope_key,
                ):
                    yield response
                return
            except Exception as exc:
                self.logger.error(
                    "OpenAI Agents runtime failed; falling back to legacy generation: %s",
                    exc,
                )
                user_input = await self.prompt_manager.compose_prompt(
                    initiator=self.person,
                    context=self.context,
                    user_transcribed_message=transcribed_user_message,
                )

        # Explicit communication history confuses the structured output generation
        communication_history = None

        # Determine the output type based on the input data
        dynamic_output_type_model = self._create_dynamic_output_type_model()
        output_type_model: AIAgentResponseOutputTypeModel = (
            await self.models_toolkit.text_model.arun(
                system_prompt=system_prompt,
                pydantic_model=dynamic_output_type_model,
                user_input=user_input,
                communication_history=communication_history,
            )
        )
        output_type = output_type_model.output_type

        # Process the input data based on the output type
        if isinstance(output_type, AudioResponse):
            if not self._can_use_model("audio_generation"):
                raise ValueError(
                    "Audio generation is not allowed with the current model configuration."
                )
            audio_response = (
                await self.models_toolkit.audio_generation_model.arun_default(
                    system_prompt=system_prompt,
                    user_input=output_type.audio_text_to_generate,
                    voice=output_type.voice,
                    communication_history=communication_history,
                )
            )
            final_response = AIAgentStreamingResponse(
                audio_bytes=audio_response.audio_bytes,
                audio_description=output_type.audio_text_to_generate,
            )
        elif isinstance(output_type, TextWithImageStreamingResponse):
            if not self._can_use_model("image_generation"):
                raise ValueError(
                    "Image generation is not allowed with the current model configuration."
                )
            image_response_task = asyncio.create_task(
                self.models_toolkit.image_generation_model.arun_default(
                    system_prompt=system_prompt,
                    user_input=output_type.image_description_to_generate,
                    communication_history=communication_history,
                )
            )
            adjusted_text_generation_system_prompt = (
                f"{system_prompt}\n"
                "Generate text assuming that the image with the following description has "
                "already been generated and it will be attached to the response as an attachment "
                "automatically (do not mention it in the text):"
                f"\n{output_type.image_description_to_generate}"
            )
            total_text = ""
            async for chunk in self.models_toolkit.text_model.astream_default(
                system_prompt=adjusted_text_generation_system_prompt,
                user_input=user_input,
                communication_history=communication_history,
            ):
                if chunk.text_chunk:
                    total_text += chunk.text_chunk
                    yield AIAgentStreamingResponse(
                        is_final_response=False,
                        total_text=total_text,
                        text_new_chunk=chunk.text_chunk,
                    )
            image_response = await image_response_task
            final_response = AIAgentStreamingResponse(
                total_text=total_text,
                image_url=image_response.image_url,
                image_description=output_type.image_description_to_generate,
            )
        elif isinstance(output_type, TextStreamingResponse):
            total_text = ""
            async for chunk in self.models_toolkit.text_model.astream_default(
                system_prompt=system_prompt,
                user_input=user_input,
                communication_history=communication_history,
            ):
                total_text += chunk.text_chunk
                yield AIAgentStreamingResponse(
                    is_final_response=False,
                    total_text=total_text,
                    text_new_chunk=chunk.text_chunk,
                )
            final_response = AIAgentStreamingResponse(
                total_text=total_text, text_new_chunk=""
            )
        else:
            raise ValueError("Unexpected output type received from the model.")
        final_response = self.inject_price(
            output=final_response,
            transcribed_user_message=transcribed_user_message,
            system_prompt=system_prompt,
            communication_history=communication_history,
        )
        final_response = await self.inject_autofact(
            output=final_response,
            transcribed_user_message=transcribed_user_message,
            system_prompt=system_prompt,
            communication_history=communication_history,
        )
        final_response.transcribed_user_message = transcribed_user_message
        yield final_response

    async def _astream_openai_agent(
        self,
        transcribed_user_message: TranscribedMessage,
        prepared_user_input: str,
        system_prompt: str,
        scope_key: Optional[str],
    ) -> AsyncGenerator[AIAgentStreamingResponse, None]:
        instructions = "\n".join(
            [
                system_prompt,
                "Use the available memory tools to retrieve durable user or chat facts when they are relevant.",
                "Do not assume facts that were not provided in the current input or returned by tools.",
                "Keep responses natural and concise.",
            ]
        )
        runtime = OpenAIAgentsRuntime(
            model=self.memory_manager.memory_config.agent_model,
            openai_api_key=self.memory_manager.openai_api_key,
        )
        tools = self.memory_manager.get_agent_tools(self.person, self.context)
        total_text = ""
        provider_metadata = {}
        async for chunk in runtime.stream(
            instructions=instructions,
            input=AgentInput(text=prepared_user_input),
            tools=tools,
            memory_state=MemoryState(scope_key=scope_key),
        ):
            if not chunk.text_chunk:
                continue
            provider_metadata = chunk.provider_metadata or provider_metadata
            total_text = chunk.total_text or (total_text + chunk.text_chunk)
            yield AIAgentStreamingResponse(
                is_final_response=False,
                total_text=total_text,
                text_new_chunk=chunk.text_chunk,
            )

        final_response = AIAgentStreamingResponse(
            total_text=total_text,
            text_new_chunk="",
        )
        final_response = self.inject_price(
            output=final_response,
            transcribed_user_message=transcribed_user_message,
            system_prompt=system_prompt,
            communication_history=None,
        )
        final_response = await self.inject_autofact(
            output=final_response,
            transcribed_user_message=transcribed_user_message,
            system_prompt=system_prompt,
            communication_history=None,
        )
        if scope_key:
            await self.db.chats.set_memory_scope(
                context=self.context,
                scope_key=scope_key,
                memory_scope={
                    "scope_key": scope_key,
                    "participants": [get_participant_key(self.person)],
                    "updated_at": datetime.utcnow(),
                    "provider_metadata": {"openai": provider_metadata},
                },
            )
        final_response.transcribed_user_message = transcribed_user_message
        yield final_response

    def inject_price(
        self,
        output: AIAgentStreamingResponse,
        transcribed_user_message: TranscribedMessage,
        system_prompt: Optional[str] = None,
        communication_history: Optional[List[OpenAIMessage]] = None,
    ) -> AIAgentStreamingResponse:
        """
        Inject the price into the AIAgentStreamingResponse based on the input and output.
        """
        total_input_text = (
            (transcribed_user_message.message_text or "")
            + (system_prompt or "")
            + "\n".join([msg["text"] for msg in communication_history or []])
        )

        # Only calculate prices for allowed models
        input_image = (
            transcribed_user_message.image_description
            if self._can_use_model("vision")
            else None
        )
        output_image_url = (
            output.image_url if self._can_use_model("image_generation") else None
        )
        input_audio = (
            transcribed_user_message.voice_description
            if self._can_use_model("audio_recognition")
            else None
        )
        output_audio = (
            output.audio_bytes if self._can_use_model("audio_generation") else None
        )

        price = self.models_toolkit.get_price(
            input_text=total_input_text,
            output_text=output.total_text,
            input_image=input_image,
            output_image_url=output_image_url,
            input_audio=input_audio,
            output_audio=output_audio,
        )
        modified_response = output
        modified_response.total_price = price
        return modified_response

    async def inject_autofact(
        self,
        output: AIAgentStreamingResponse,
        transcribed_user_message: TranscribedMessage,
        system_prompt: Optional[str] = None,
        communication_history: Optional[List[OpenAIMessage]] = None,
    ) -> AIAgentStreamingResponse:
        """
        Inject the autofact into the AIAgentStreamingResponse based on the input and output.
        """
        if not self.autofact_enabled:
            return output

        existing_facts = await self.prompt_manager.compose_chat_facts_prompt(
            self.context
        )
        existing_user_facts = await self.prompt_manager.compose_user_facts_prompt(
            self.person, self.context
        )

        prompt = (
            "We got the following response from the agent:"
            f"{output.total_text}\n\n"
            "Which was a response based on the following message from the user "
            f"with handle {self.person.user_handle}:"
            f"{transcribed_user_message.message_text}\n\n"
            "Which was a response based on the following system prompt:"
            f"{system_prompt}\n\n"
            "Which was a response based on the following communication history:"
            f"{communication_history}\n\n"
            f"{existing_facts}\n"
            f"{existing_user_facts}\n"
            "Generate facts based on the above context. Avoid generating facts that are "
            "already saved in our database (see existing facts above).\n"
            "IMPORTANT: For the user_handle field, use the user's handle (e.g., '@username'), "
            "NOT their display name or first name."
        )
        facts: ResponseFactsGeneration = await self.models_toolkit.text_model.arun(
            system_prompt=system_prompt,
            pydantic_model=ResponseFactsGeneration,
            user_input=prompt,
        )
        if facts.facts_generation_needed:
            self.logger.info(f"Generated new facts: {facts.user_facts}")
            output.generated_facts = facts.user_facts
        else:
            self.logger.info("No new facts generated for the message")
            output.generated_facts = []
        return output
