from typing import List

from ...models.handlers_response import CommandResponse
from ...models.handlers_input import Person, Context, Message
from ..callbacks.set_chat_mode_handler import CallbackHandler
from ..callbacks.show_chat_modes_handler import ShowChatModesMixin
from ..rp_bot_handlers import RPBotCommandHandler


class CommandHandler(ShowChatModesMixin, RPBotCommandHandler):
    needs_terms_accepted = CallbackHandler.needs_terms_accepted
    permission_classes = CallbackHandler.permission_classes
    command = "mode"

    async def get_response(
        self, person: Person, context: Context, message: Message, args: List[str]
    ) -> CommandResponse:
        return CommandResponse(
            text="choose_mode",
            keyboard=await self._get_chat_modes_keyboard(
                db=self.db,
                context=context,
                callback_action=CallbackHandler.callback_action,
            ),
        )
