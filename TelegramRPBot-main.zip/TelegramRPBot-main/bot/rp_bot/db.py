from typing import Optional, List

from motor.motor_asyncio import AsyncIOMotorClient

from ..models.config import DefaultChatModes
from ..models.handlers_input import Person, Context
from .db_models.chats import Chats
from .db_models.user_facts import UserFacts
from .db_models.user_introductions import UserIntroductions
from .db_models.chat_modes import ChatModes
from .db_models.dialogs import Dialogs
from .db_models.users import Users
from .db_models.user_usage import UserUsage
from .storage import (
    BaseStore,
    ChatModesStore,
    ChatsStore,
    RecentDialogStore,
    UserFactsStore,
    UserIntroductionsStore,
    UsersStore,
    UserUsageStore,
)


class DB:
    def __init__(
        self,
        db_uri: str,
        default_language: str,
        default_chat_modes: DefaultChatModes,
        last_n_messages_to_remember: int,
        last_n_messages_to_store: Optional[int],
        default_usage_limit: int,
    ):
        client = AsyncIOMotorClient(db_uri)
        db = client.get_default_database()
        self.users: UsersStore = Users(db)
        self.user_usage: UserUsageStore = UserUsage(db, default_usage_limit)
        self.chats: ChatsStore = Chats(db, default_language)
        self.user_facts: UserFactsStore = UserFacts(db)
        self.user_introductions: UserIntroductionsStore = UserIntroductions(db)
        self.chat_modes: ChatModesStore = ChatModes(db, default_chat_modes)
        self.dialogs: RecentDialogStore = Dialogs(
            db, last_n_messages_to_remember, last_n_messages_to_store
        )
        self.models: List[BaseStore] = [
            self.users,
            self.user_usage,
            self.chats,
            self.user_facts,
            self.user_introductions,
            self.chat_modes,
            self.dialogs,
        ]

    async def create_if_not_exists(self, person: Person, context: Context) -> None:
        for model in self.models:
            await model.create_if_not_exists(context=context, person=person)

    async def update_if_needed(self, person: Person, context: Context) -> None:
        for model in self.models:
            await model.update_if_needed(person=person, context=context)

    async def clear_user_data(self, user_handle: str) -> None:
        # TODO: implement this method for all models
        for model in self.models:
            await model.clear_user_data(user_handle)
